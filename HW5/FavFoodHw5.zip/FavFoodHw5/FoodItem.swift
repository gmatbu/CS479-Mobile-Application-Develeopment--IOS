//
//  FoodItem.swift
//  FavFoodHw5
//
//  Created by Gizem Melisa Ates on 2/19/20.
//  Copyright © 2020 Gizem Melisa Ates. All rights reserved.
//

import UIKit

class FoodItem {
    
    var foodname: String
    var foodimage: String
    var foodcal: Int
    
    init() {
        foodname = "food"
        foodimage = "newFood.png"
        foodcal = 999
    }
}
