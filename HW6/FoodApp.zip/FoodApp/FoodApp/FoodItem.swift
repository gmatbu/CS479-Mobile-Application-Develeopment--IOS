//
//  FoodItem.swift
//  FoodApp
//
//  Created by Larry Holder on 2/12/20.
//  Copyright © 2020 Washington State University. All rights reserved.
//

import Foundation

class FoodItem {
    var name: String
    var imageFileName: String
    var caloriesPerServing: Int
    var unsortedIndex: Int
    
    init(name: String, imageFileName: String, caloriesPerServing: Int, unsortedIndex: Int) {
        
        if (name == ""){
            self.name = "Food"
            self.caloriesPerServing = 80
            self.imageFileName = "food1.jpg"
            self.unsortedIndex = unsortedIndex
        }
        else{
            self.name = name
            self.imageFileName = imageFileName
            self.caloriesPerServing = caloriesPerServing
            self.unsortedIndex = unsortedIndex
        }
        
    }
}
